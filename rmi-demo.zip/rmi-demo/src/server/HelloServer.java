import java.rmi.Naming;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;

public class HelloServer {
    public static void main(String[] args) {
        try {
            LocateRegistry.createRegistry(1099); // Start RMI registry on default port 1099
            HelloImpl obj = new HelloImpl();
            Naming.rebind("Hello", obj);
            System.out.println("HelloServer is ready.");
        } catch (Exception e) {
            System.err.println("HelloServer exception: " + e.toString());
            e.printStackTrace();
        }
    }
}