print ("hello") 

a= 'Hello'
b=" World"

a = ["1","2","3"]
print(a) 

thistuple = ("apple", "mango", "cherry",18)
print (thistuple) 

dict = { 'name':"Hardik", 'surname':"Pandya"} 

A=10
if(A>0):
	print('yes') 

a=10
if(a>0):
 print ("Yes!")
else:
 print ("No *") 

x = 0
#traditional python if elif else statement
if x > 0:
 print("Positive")
elif x < 0:
 print("Negative")
else:
 print("Zero") 

val = input ("Enter your value: ")
print(val)
name = input ("Enter your name: ")
print(name) 

a=5
print (a) 

b=10
print ("value of b is:", b) 

#You can use double or single quotes:
print("Hello")
print('Hello') 

print ("It's alright")
print ("He is called 'Johnny'")
print ('He is called "Johnny"') 

a = "Hello"
print(a) 

a = """BCA SEM 5"""
print(a) 

a = '''BCA SEM 5'''
print(a) 

count = 0
while (count < 10):
 print ('The number is:', count)
 count = count + 1
print ("Good bye!") 

colors = ["red", "blue", "green"]
for x in colors:
 print(x) 

for i in range(1,10,2):
 print(i) 

for x in range (1,10,1):
 print(x) 

for i in range (1,2):
 for j in range (1,6):
  print(j)
 print ("End!") 

a = 33
b = 200
if b > a:
 pass
# having an empty if statement like this, would raise an error without the pass
# statement 

def fun ():
 #function Created
 print ("Welcome to Python!")
fun ()
# Calling a function 

# Simple Python Function
def multiply(x,y):
 print (x*y)
multiply (5,2) 

def my_function(fname):
 print (fname + " BCA")
my_function("FY")
my_function("SY")
my_function("TY") 

def f():
 # local variable
 a=20
 b=10
 s = a+b
 print(s)
f() 

def I_scope():
 message = 'Hello'
 print('Local Scope: ', message)
I_scope() 

# declare global variable
message = 'Hello !'
def greet():
 # declare local variable
 print('Local Scope:', message)
greet()
print('Global Scope:', message) 

def demo():
 print('Recursion In Python !')
demo()
demo() 

def countdown(n):
 while n >= 0:
  print(n)
  n -= 1
countdown(10) 

x = "awesome"
def myfunc ():
 print ("Python is " + x)
myfunc () 

def greeting(name):
 print('Hello,'+ name)
def add(a, b):
 print('Sum is:',a+b) 

# main.py
import firstmodule as first
first.greeting('Students!')
first.add(12,3) 

import platform
x = platform.system()
print(x) 

file=open('test.txt','w')
file.write('Hello, TYBCA...')
file.write("This is our new text file")
file.close()
print("File Operation successfully completed") 

file=open('test.txt','r')
print(file.read())
print("File Operation successfully completed") 

import os
#os.remove("demofile.txt") 

thislist = ["red", 25, "blue", 44.23]
print(thislist) 

x=[12,32,44,36.21,'TYBCA']
print(x) 

thislist = ["apple", True, "cherry", 25]
print(thislist[-1]) 

s=[22,55,12,35,True,87.4,'Virat',98.5,'Kohli',100,1]
print(s) 

thislist = ["apple", "mango", "cherry"]
thislist[1] = "blackcurrant"
print(thislist) 

thislist = ["apple", "mango", "cherry"]
thislist.insert(2, "watermelon")
print(thislist) 

thislist = [123, True, "cherry",25, 'College']
thislist.append("orange")
print(thislist) 

thislist = ["green", 22, "yellow"]
color = ["blue", 26, "red"]
thislist.extend(color)
print(thislist) 

thislist = ['FYBCA', 'TYBCA', 2024]
thislist.insert(1, 'SYBCA')
print(thislist) 

points = [1, 4, 2, 9, 7, 8, 9, 3, 1]
x= points.count(9)
print(x) 

f = [4, 55, 64, 32, 16, 32]
x = f.index(32)
print(x) 

thislist = ["abc", 25, "pqr", 7, "xyz"]
thislist.remove("pqr")
print(thislist) 

a = [22,33,44,55,66,77]
a.pop(1)
print(a) 

a = [22,33,44,55,66,77]
a.pop()
print(a) 

thislist = [11,22,33]
del thislist[1]
print(thislist) 

thislist = [1,2,3,4,5]
del thislist 

mylist = [1,2,3,'jsjs',5]
x = len(mylist)
print(x) 

i=[1,22,55,88]
max(i) 

i=[1,22,55,88]
min(i) 

a = (1, 11, 2, 22)
x = sorted(a)
print(x) 

x=('a','r','q','b',)
a=sorted(x)
print(a) 

thistuple = ("J2EE", 22, "Python", 2, "CyberSecurity")
print(thistuple) 

# Initialize tuple
tupl = ('Python', 'SQL')
# Initialize another Tuple
tup2 = ('R',)
# Create new tuple based on existing tuples
new_tuple = tupl + tup2;
print(new_tuple) 

t1 = ('a', 'b', 'c', 'd', 'e')
print ('Tuple:', t1[3]) 

T1= ('a', 's', 'q', 'd', 'r')
T2= (1,2,3,4,5)
T3=T1+T2
print(T3) 

T1=('a','d','k','l')
del (t1)
print(T1) #this will raise an error because the tuple no longer exists 

#You can use double or single quotes:
print("Hello")
print('Hello') 

var1 ='hello world'
var2 ='python programming'
print ('var1[1]:', var1[1])
print('var2[1:5]', var2[1:5]) 

var1 = 'hello world'
print ('updated string: -', var1[:6] + 'python') 

var1='hello'+'_students'
print(var1) 

v='Hello!'
print(v*3) 

str1 = 'Java'
str2 = 'Java 2 Enterprise Edition'
str3 = 'SEO'
str4 = 'Cyber Security'
str5 = 'IT'
print ('Java' in str2)
print ('SEO' not in str3) 

b='python'
b.upper() #Converts a string into upper case
b.islower() #Returns True if all characters in the string are lower case
b.isdigit() #Returns True if all characters in the string are digits
b.capitalize() #Converts the first character to upper case
b.count('h') #Returns the number of times a specified value occurs in a s
#tring 

d1 = {'name': 'ABC', 'city': 'Rajkot', 'age': 15}
print(d1) 

D1 = {'name': 'XYZ', 'city': 'Jetpur', 'age': 25}
print ("Name is:", D1['name']) 

D1 = {'name': 'XYZ', 'city': 'Jetpur', 'age': 25}
D1['college'] = 'GK&CK Bosamiya Collage' #adding new entry
D1['age']=21 #modifying existing entry
print(D1) 

D1 = {'name': 'ABC', 'city': 'Rajkot', 'age': 5}
del (D1 ['name']) # removing single entry
print(D1) 

D1 = {'name': 'ABC', 'city': 'Rajkot', 'age': 5}
D1. clear () # remove all entries in dictionary Print(D1)
print(D1) 

D1 = {'name': 'ABC', 'city': 'Rajkot', 'age': 5}
#del (D1) # deleting entire dictionary
print(D1) 
d1 = {'name': 'ABC', 'city': 'Rajkot', 'age': 15}
print(d1) 

D1 = {'name': 'XYZ', 'city': 'Jetpur', 'age': 25}
print ("Name is:", D1['name']) 

D1 = {'name': 'XYZ', 'city': 'Jetpur', 'age': 25}
D1['college'] = 'GK&CK Bosamiya Collage' #adding new entry
D1['age']=21 #modifying existing entry
print(D1) 

D1 = {'name': 'ABC', 'city': 'Rajkot', 'age': 5}
del (D1 ['name']) # removing single entry
print(D1) 

D1 = {'name': 'ABC', 'city': 'Rajkot', 'age': 5}
D1.clear() # remove all entries in dictionary 
print(D1) 

D1 = {'name': 'ABC', 'city': 'Rajkot', 'age': 5}
#del (D1) # deleting entire dictionary
try:
    print(D1) # This will raise an error since D1 no longer exists
except NameError:
    print("D1 is no longer defined")