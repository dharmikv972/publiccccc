a=int(input("Enter Your Value: "))
b=int(input("Enter Your Value: "))
try:
  x=a/b
except:
  print('Dont input zero...')
else:
  print(x)
finally:
  print('THANK YOU !')

a=int(input("Enter Your Value: "))
b=int(input("Enter Your Value: "))
try:
  x=a/b
except NameError:
  print("Variable x is not defined")
except ZeroDivisionError:
  print("Something else went wrong")
else:
  print(x)

x=int(input('Enter Number:'))
assert x>0, "Number should be positive"
print("Number is Positive") 

#class: An Abstract data type:
class testing():
  a=1
  def display(self):
    print('This is class method:')
    t1=testing()
    print('value of a is :',t1.a)
t1=testing()
t1.display

class student:
  def __init__(self, name, age):
    self.name = name
    self.age = age
p1 = student ("John", 20)
print(p1.name)
print(p1.age)

class employee:
  def __init__(self): #method1
    self.id=int(input('Enter ID:'))
    self.name=input('Enter Name:')
    self.salary=int(input('Enter Salary:'))
  def display(self): #method 2
    print('Employee ID:', self.id)
    print('Employee Name:',self.name)
    print('Employee Salary:', self.salary)
a=employee()
a.display()

class Father:
  def func_1(self):
    print ("This function is defined inside the parent class.")
class Son(Father):
  def func_2(self):
    print ("This function is defined inside the child class.")
object = Son()
object.func_1()
object.func_2()

class A:
  num1=int(input('Enter First Number:'))
  num2=int(input('Enter Second Number:'))
  def Add(self):
    print ("Addition : ",self.num1+self.num2)
  def Sub(self):
    print ("Substraction : ",self.num1-self.num2)
class B(A):
  def Multi(self):
    print ("Multiplication : ",self.num1*self.num2)
  def Div(self):
    print ("Division : ",self.num1/self.num2)
  def Modular1(self):
    print ("Remaining Value : ",self.num1%self.num2)
object = B()
object.Add()
object.Multi()
object.Div()
object.Sub()
object.Modular1() 

class Person1:
  Back="Oracle DB & Java"
  def Backend(self):
    print('Backend Task implemented using:',self.Back)
class Person2:
  Front="HTML CSS Javascript"
  def Frontend(self):
    print('Frontend Task implemented using:', self. Front)
class Teamhead (Person1, Person2):
  def Show(self):
    print('Dynamic Website Created.....')
T1=Teamhead()
T1.Backend()
T1.Frontend()
T1.Show() 

class Father:
  surname="Sharma"
class Son (Father):
  def Show(self):
    print('ABC:',self.surname)
class GSon(Son):
  def Disp(self):
    print('XYZ',self.surname)
Gs=GSon()
Gs.Disp()
Gs.Show() 

class Father:
  surname="Kapoor"
  def Show(self):
    print('My Surname is:', self.surname)
class Son1(Father):
  def Disp1(self):
    print('My name is Tansh', self.surname)
class Son2(Father):
  def Disp2(self):
    print('My name is Ansh',self.surname)
s1=Son1()
s1.Disp1()
s2=Son2()
s2.Disp2()

class A:
  def Disp1(self):
    print('Class A')
class B(A):
  def Show1(self):
    print('Class B')
class C(A):
  def Disp2(self):
    print('Class C')
class D(B,C):
  def Show2(self):
    print('Class D')
ob=D()
ob.Disp1()
ob.Show1()
ob.Disp2()
ob.Show2()

class Calculation1:
  def Summation(self,a,b):
    return a+b;
class Calculation2:
  def Multiplication(self,a,b):
    return a*b;
class Derived(Calculation1, Calculation2):
  def Divide(self,a,b):
    return a/b;
d = Derived()
print(issubclass(Derived,Calculation2))
print(issubclass(Calculation1, Calculation2))

class Calculation1:
  def Summation(self,a,b):
    return a+b;
class Calculation2:
  def Multiplication(self,a,b):
    return a*b;
class Derived(Calculation1,Calculation2):
  def Divide(self,a,b):
    return a/b;
d = Derived()
print(isinstance(d,Derived))

class num():
  def __init__(self):
    self.a = 123
    self._b = 456
    self._c = 789
obj=num()
print(obj.a)
print(obj._b)
print(obj._c)

class JustCounter:
  __secretCount = 0
  def count(self):
    self.__secretCount += 1
    print (self.__secretCount)
counter = JustCounter()
counter.count()
counter.count()
counter.count()
print (counter._JustCounter__secretCount)
#print (counter.__secretCount)

#Linear Search
x = [1,2,3,4,5,6,7,8,9,10,12,15,22,25,28,30,31,32,45,60,80]
n = int(input("Enter number to search: "))
found = False
for i in range(0,len(x)):
  if(n==x[i]):
    found = i+1
    break
if(found == False):
  print("Number not Found!")
else:
  print("Number found in ",found, "Location")

#binary search
Ls = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15]
n = int (input ("Enter number to search: "))
first = 0
last=len(Ls)-1
while first<=last:
  mid=(first+last)//2
  if Ls[mid]==n:
    print ("Number found in ",mid+1,"Location")
    break
  elif Ls[mid]>n:
    last=mid-1
  else:
    first=mid+1
if first>last:
  print ("Number not Available in the List")

num = [5,8,3,4,1,7,2,6]
num.sort()
print(num) 

#Selection Sort
def selection(ar,size):
  for i in range(size):
    min_index=i
    for j in range(i+1, size):
      if ar[j]<ar[min_index]:
        min_index=j
    (ar[i],ar[min_index])=(ar[min_index],ar[i])
arr=[-11,26,77,8,-9,21,11,1015]
selection(arr,len(arr))
print(arr)

#Bubble Sort
x=[4,3,5,6,7,1,2,10,8,9]
for i in range(0,len(x)):
  for j in range(0, len(x)-1):
    if x[j]>x[j+1]:
      c=x[j]
      x[j]=x[j+1]
      x[j+1]=c
print(x) 

#Insertion Sort
x=[44,35,55,66,57,21,12,10,98,100,9]
for i in range(1,len(x)):
  c=i
  while c>0 and x[c]<x[c-1]:
    a=x[c]
    x[c]=x[c-1]
    x[c-1]=a
    c=c-1
print(x)

def merge_sort(arr):
  if len(arr) <= 1:
    return arr
  mid = len(arr) // 2
  l_half = arr[:mid]
  r_half = arr[mid:]
  I_half = merge_sort(l_half)
  r_half = merge_sort(r_half)
  return merge(l_half, r_half)
def merge(left, right):
  result = []
  i,j=0,0
  while i < len(left) and j < len(right):
    if left[i] < right[j]:
      result.append(left[i])
      i += 1
    else:
      result.append(right[j])
      j += 1
  result.extend(left[i:])
  result.extend(right[j:])
  return result
unsortedArr = [3, 7, 6, -10, 15, 23.5, 55, -13]
sortedArr = merge_sort(unsortedArr)
print("Sorted array:", sortedArr)

def shellSort(array, n):
# Rearrange elements at each n/2, n/4, n/8, ... intervals
  interval = n // 4
  while interval > 0:
    for i in range(interval, n):
      temp = array[i]
      j = i
      while j >= interval and array[j - interval] > temp:
        array[j] = array[j - interval]
        j -= interval
      array[j] = temp
    interval //= 2
data = [33,31,40,8,12,17,25,42]
size = len(data)
shellSort(data, size)
print('Sorted Array in Ascending Order:')
print(data) 

dict = {'Name': 'Ajay', 'Age': 30, 'City':'Jetpur'}
print("dict['Name'): ", dict['Name'])
hash (5)
hash('a')
hash ('A')
hash ('Bosamia')

new_dict={'name':'Jack','age':'24','city':'Rajkot'}
print(new_dict)
new_dict['name']
print(new_dict.keys())
print(new_dict.values())
print(new_dict.get('age'))
for x in new_dict:
  print(x)
for x in new_dict.values():
  print(x)
for x,y in new_dict.items():
  print(x,y) 