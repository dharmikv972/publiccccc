def greeting(name):
 print('Hello,'+ name)
def add(a, b):
 print('Sum is:',a+b) 
 